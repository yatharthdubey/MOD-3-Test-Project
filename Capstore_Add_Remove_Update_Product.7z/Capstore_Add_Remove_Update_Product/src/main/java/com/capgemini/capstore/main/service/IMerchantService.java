package com.capgemini.capstore.main.service;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import com.capgemini.capstore.main.beans.Customer;
import com.capgemini.capstore.main.beans.Merchant;
import com.capgemini.capstore.main.beans.Offer;
import com.capgemini.capstore.main.beans.Order;
import com.capgemini.capstore.main.beans.Product;
import com.capgemini.capstore.main.beans.User;

public interface IMerchantService {
	
	
	boolean ValidateLogIn(User user);

	Merchant getMerchant(int merchantId);

	boolean ValidateUserDetails(@Valid User user);

	Customer ValidateCustomerDetails(@Valid Customer customer);

	Merchant ValidateMerchantDetails(@Valid Merchant merchant);

	boolean isValidResetPasswordRequest(String email);

	String isValidEmail(String email);

	void updatePassword(String email, String password);

	boolean checkSequirityAnswer(String email, String sequirityAnswer);

	boolean changePassword(String email, String oldPassword, String newPassword);

	Product addProduct(@Valid Product product, String merchantEmail);

	Product updateProduct(@Valid Product product, String merchantEmail);

	Product getProduct(int productId, String merchantEmail);

	boolean removeProduct(int productId, String merchantEmail);

	Order findOrder(String userId, int orderId);
	
	public Offer applyOffer(int merchantId,int category,String offerDescription, Date offerStartDate, Date offerEndDate,double discountOffered,String softDelete);

	List<Offer> applyOfferByCategory(int merchantId, String productCategory, String offerDescription, Date offerStartDate,
			Date offerEndDate, double discountOffered, String softDelete);

	double findByMerchantAndProduct(int merchantId, int productId);

}
