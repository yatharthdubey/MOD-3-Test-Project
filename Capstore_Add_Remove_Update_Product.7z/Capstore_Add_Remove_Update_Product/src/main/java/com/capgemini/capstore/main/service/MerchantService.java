package com.capgemini.capstore.main.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.main.beans.Customer;
import com.capgemini.capstore.main.beans.Merchant;
import com.capgemini.capstore.main.beans.Offer;
import com.capgemini.capstore.main.beans.Order;
import com.capgemini.capstore.main.beans.Product;
import com.capgemini.capstore.main.beans.User;
import com.capgemini.capstore.main.dao.CapStoreCustomer;
import com.capgemini.capstore.main.dao.CapStoreMerchant;
import com.capgemini.capstore.main.dao.CapStoreOffer;
import com.capgemini.capstore.main.dao.CapStoreOrder;
import com.capgemini.capstore.main.dao.CapStoreProduct;
import com.capgemini.capstore.main.dao.CapStoreUser;

@Service
public class MerchantService implements IMerchantService {

	@Autowired
	private CapStoreMerchant merchantRepo;

	@Autowired
	private CapStoreProduct productRepo;
	
	@Autowired
	private CapStoreOrder orderRepo;

	@Autowired
	private CapStoreCustomer customerRepo;

	@Autowired
	private CapStoreUser userRepo;
	
	@Autowired
	private CapStoreOffer capStoreOffer;


	@Override
	public Product getProduct(int productId, String merchantEmail) {

		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail);
		for (Product product : merchant.getProducts()) {
			if (product.getProductId() == productId) {
				return product;
			}
		}
		return null;
	}

	@Override
	public Product addProduct(@Valid Product product, String merchantEmail) {

		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail);

		List<Product> productList = merchant.getProducts();
		productList.add(product);
		merchantRepo.save(merchant);
		return product;
	}

	@Override
	public Product updateProduct(@Valid Product product, String merchantEmail) {

		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail);
		for (Product productObj : merchant.getProducts()) {
			if (product.getProductId() == productObj.getProductId()) {
				productObj = product;
				return product;
			}
		}
		merchantRepo.save(merchant);
		return null;
	}

	@Override
	public boolean removeProduct(int productId, String merchantEmail) {

		Merchant merchant = merchantRepo.findByMerchantEmail(merchantEmail);
		Iterator<Product> itr = merchant.getProducts().iterator();
		while (itr.hasNext()) {
			Product product = itr.next();
			if (product.getProductId() == productId) {
				itr.remove();
				productRepo.deleteById(productId);
				merchantRepo.save(merchant);
				return true;
			}
		}
		return false;
	}
	
	@Override
	public Order findOrder(String userId, int orderId) {
		
		Order order = orderRepo.findById(orderId).get();
		
		if(order.getCustomer().getCustomerEmail().equals(userId)) {
			return order;
		}
		return null;
	}
	
	@Override
	public boolean ValidateLogIn(User user) {

		User result = null;
		try {
			result = userRepo.findById(user.getEmailId()).get();
			// System.out.println(result.getEmailId()+" "+result.getPassword());
		} catch (Exception e) {

			e.printStackTrace();
		}
		if (result != null) {
			MD5 encryption = new MD5();
			user.setPassword(encryption.encryptText(user.getPassword()));
			if (result.equals(user)) {
				return true;
			}
			return false;
		}
		return false;
	}

	@Override
	public Merchant getMerchant(int merchantId) {
		return merchantRepo.getOne(merchantId);
	}

	@Override
	public boolean ValidateUserDetails(@Valid User user) {
		MD5 encryption = new MD5();
		user.setPassword(encryption.encryptText(user.getPassword()));
		Optional<User> result = userRepo.findById(user.getEmailId());
		if (result.isPresent()) {
			return false;
		}
		userRepo.save(user);
		return true;
	}

	@Override
	public Customer ValidateCustomerDetails(@Valid Customer customer) {
		return customerRepo.save(customer);
	}

	@Override
	public Merchant ValidateMerchantDetails(@Valid Merchant merchant) {
		return merchantRepo.save(merchant);
	}

	@Override
	public boolean isValidResetPasswordRequest(String email) {

		return false;
	}

	@Override
	public String isValidEmail(String email) {
		try {
			User user = userRepo.findById(email).get();
			return user.getSecurityQuestion();
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public boolean checkSequirityAnswer(String email, String sequirityAnswer) {
		try {
			User user = userRepo.findById(email).get();
			if (user.getSecurityAnswer().equalsIgnoreCase(sequirityAnswer)) {
				return true;
			}
			return false;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public void updatePassword(String email, String password) {
		MD5 encryption = new MD5();
		password = encryption.encryptText(password);
		try {
			User user = userRepo.findById(email).get();
			user.setPassword(password);
			userRepo.save(user);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public boolean changePassword(String email, String oldPassword, String newPassword) {
		MD5 encryption = new MD5();
		oldPassword = encryption.encryptText(oldPassword);
		newPassword = encryption.encryptText(newPassword);
		try {
			User user = userRepo.findById(email).get();
			if (user.getPassword().equals(oldPassword)) {
				user.setPassword(newPassword);
				userRepo.save(user);
				return true;
			}
			return false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<Offer> applyOfferByCategory(int merchantId,String productCategory,String offerDescription, Date offerStartDate, Date offerEndDate,double discountOffered,String softDelete) {
		List<Product> products=productRepo.findByProductCategory(productCategory);
		List<Offer> offers=new ArrayList<>();
		for(Product product:products)
		{
		Offer offer = new Offer();
		offer.setMerchant(merchantRepo.findById(merchantId).get());
		offer.setProduct(product);
//		offer.setOfferId(offerId);
		offer.setOfferDescription(offerDescription);
		offer.setOfferStartDate(offerStartDate);
		offer.setOfferEndDate(offerEndDate);
		offer.setDiscountOffered(discountOffered);
		offer.setSoftDelete(softDelete);
		System.out.println(offer);
		capStoreOffer.save(offer);
		offers.add(offer);
		}
		return offers;
	}
	
	
	
	
	@Override
	public Offer applyOffer(int merchantId,int productid,String offerDescription, Date offerStartDate, Date offerEndDate,double discountOffered,String softDelete) {
		
		Offer offer = new Offer();
		offer.setMerchant(merchantRepo.findById(merchantId).get());
		offer.setProduct(productRepo.findById(productid).get());
//		offer.setOfferId(offerId);
		offer.setOfferDescription(offerDescription);
		offer.setOfferStartDate(offerStartDate);
		offer.setOfferEndDate(offerEndDate);
		offer.setDiscountOffered(discountOffered);
		offer.setSoftDelete(softDelete);
		capStoreOffer.save(offer);
		return offer;
	}
	
	
	@Override
	public double findByMerchantAndProduct(int merchantId,int productId)
	{	
		Product product=productRepo.findById(productId).get();
		double productMRP=product.getProductPrice();
		List<Offer> offerlist=capStoreOffer.findByMerchantAndProduct(merchantRepo.findById(merchantId).get(),productRepo.findById(productId).get());
		for(Offer offer:offerlist)
		{
			if(offer.getSoftDelete().equals("A"))
			{
			double discount=offer.getDiscountOffered();
			double finalPrice=(productMRP*(100-discount)/100);
			return finalPrice;
			}
		}
		return productMRP;
	}

}
