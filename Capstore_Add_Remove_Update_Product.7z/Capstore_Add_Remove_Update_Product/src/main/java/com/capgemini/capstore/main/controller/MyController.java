package com.capgemini.capstore.main.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.ParseException;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.beans.Customer;
import com.capgemini.capstore.main.beans.Merchant;
import com.capgemini.capstore.main.beans.Offer;
import com.capgemini.capstore.main.beans.Order;
import com.capgemini.capstore.main.beans.Product;
import com.capgemini.capstore.main.beans.User;
import com.capgemini.capstore.main.service.IMerchantService;

@RestController
public class MyController {

	@Autowired
	IMerchantService service;
	
	@RequestMapping(value = "/")
	public String homePage(HttpServletRequest request) {

		return "indexPage" + request.getSession().getAttribute("userId");
	}

	@RequestMapping(value = "/logIn", method = RequestMethod.POST)
	public String logIn(@RequestBody User user, HttpServletRequest request) {
		boolean result;
		try {
			result = service.ValidateLogIn(user);
			System.out.println(result);

			if (result) {
				// apply session here
				HttpSession session = request.getSession(true);
				session.setAttribute("userId", user.getEmailId());
				session.setAttribute("role", user.getRole());
				return "indexPageWithLogIn" + session.getAttribute("userId");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// set error msg
		return "indexPageWithErrorMsg";
	}

	@RequestMapping(value = "/logOut", method = RequestMethod.GET)
	public String logOut(HttpServletRequest request) {
		request.getSession().invalidate();
		return "indexPage";
	}

	@RequestMapping(value = "/forgotPassword/{email}", method = RequestMethod.POST)
	public String forgotPassword(@PathVariable String email, HttpServletRequest request) {
		String securityQuestion;
		if ((securityQuestion = service.isValidEmail(email)) != null) {
			request.getSession().invalidate();
			HttpSession session = request.getSession();
			session.setAttribute("email", email);
			session.setAttribute("securityQuestion", securityQuestion);
			return "checkSecurityAnswer";
		}
		return "forgotPasswordWithErrorMsg";
	}

	@RequestMapping(value = "/checkSecurityAnswer/{securityAnswer}", method = RequestMethod.POST)
	public String checkSequirityAnswer(@PathVariable String securityAnswer, HttpServletRequest request) {

		HttpSession session = request.getSession();
		if (service.checkSequirityAnswer((String) session.getAttribute("email"), securityAnswer)) {
			session.setAttribute("securityAnswer", securityAnswer);
			return "passwordChangePage";
		}

		return "forgotPasswordWithErrorMsg";
	}

	@RequestMapping(value = "/passwordChangePage/{password}", method = RequestMethod.POST)
	public String passwordChangePage(@PathVariable String password, HttpServletRequest request) {
		HttpSession session = request.getSession();
		String email = (String) session.getAttribute("email");
		service.updatePassword(email, password);
		return "logInPage";
	}

	@RequestMapping(value = "/changePassword/{oldPassword}/{newPassword}", method = RequestMethod.PUT)
	public String changePassword(@PathVariable String oldPassword, @PathVariable String newPassword,
			HttpServletRequest request) {

		HttpSession session = request.getSession();
		if (session == null) {
			return "logIn page WIth Msg you need to log In first";
		}
		if (service.changePassword((String) session.getAttribute("userId"), oldPassword, newPassword)) {
			return "passwordChangeSuccessfully";
		}
		return "changePasswordwithErrorPage";
	}

	@RequestMapping(value = "/signUp", method = RequestMethod.POST)
	public String signUp(@Valid @RequestBody User user) {

		if (service.ValidateUserDetails(user)) {
			if (user.getRole().equals("CUSTOMER")) {
				return "RegisterCustomerPage";
			} else if (user.getRole().equals("MERCHANT")) {
				return "RegisterMerchantPage";
			}
		} else {
			// set error msg details are incorrect
			return "SignUpPage";
		}
		return "SignUpPage";
	}

	@RequestMapping(value = "/RegisterCustomer", method = RequestMethod.POST)
	public Customer registerCustomer(@Valid @RequestBody Customer customer) {
		return service.ValidateCustomerDetails(customer);
	}

	@RequestMapping(value = "/RegisterMerchant", method = RequestMethod.POST)
	public Merchant registerMerchant(@Valid @RequestBody Merchant merchant) {
		return service.ValidateMerchantDetails(merchant);
	}


	@RequestMapping(method = RequestMethod.GET, value = "/getProduct/{productId}")
	public Product getProduct(@PathVariable int productId, HttpServletRequest request) {
		// HttpSession session = request.getSession();
		// if(session.getAttribute("role").equals("MERCHANT")){
		String merchantEmail = "yanshu@gupta.com";// session.getAttribute("userId");
		
		return service.getProduct(productId, merchantEmail);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/addProduct")
	public Product addProduct(@Valid @RequestBody Product product, HttpServletRequest request) {
		// HttpSession session = request.getSession();
		// if(session.getAttribute("role").equals("MERCHANT")){
		String merchantEmail = "yanshu@gupta.com";// session.getAttribute("userId");

		return service.addProduct(product, merchantEmail);
		// return "Successfull Add Product";
		/*
		 * } else{ return "errorPage"; }
		 */
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/updateProduct/{productId}")
	public Product updateProduct(@Valid @RequestBody Product product, @PathVariable int productId) {
		// HttpSession session = request.getSession();
		// if(session.getAttribute("role").equals("MERCHANT")){
		String merchantEmail = "yanshu@gupta.com";// session.getAttribute("userId");
		product.setProductId(productId);
		service.updateProduct(product, merchantEmail);
		return product;
		// return "Successfull Add Product";
		/*
		 * } else{ return "errorPage"; }
		 */
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/removeProduct/{productId}")
	public boolean removeProduct(@PathVariable int productId) {
		// HttpSession session = request.getSession();
		// if(session.getAttribute("role").equals("MERCHANT")){
		String merchantEmail = "yanshu@gupta.com";// session.getAttribute("userId");
		
		return service.removeProduct(productId, merchantEmail);
		
		// return "Successfull Add Product";
		/*
		 * } else{ return "errorPage"; }
		 */
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/invoice/{orderId}")
	public Order addProduct(@PathVariable int orderId, HttpServletRequest request) {
		//HttpSession session = request.getSession();
		String userId = "yanshu@gmail.com";//(String)session.getAttribute("userId");
		return service.findOrder(userId,orderId);
		//return new ModelAndView("error", "order", order);

	}

	@RequestMapping(value="/createOffer",method=RequestMethod.POST)
	public Offer applyOfferByPostMethod(@RequestBody Offer offer) throws ParseException, java.text.ParseException
	{
		return service.applyOffer(offer.getMerchant().getMerchantId(),offer.getProduct().getProductId(),offer.getOfferDescription(), offer.getOfferStartDate(),offer.getOfferEndDate(), offer.getDiscountOffered(),offer.getSoftDelete());
		
	}
	
	
	@RequestMapping(value="/createOfferbyCategory",method=RequestMethod.POST)
	public List<Offer> applyOfferByCategoryusingPost(@RequestBody Offer offer) throws ParseException, java.text.ParseException
	{
		return service.applyOfferByCategory(offer.getMerchant().getMerchantId(),offer.getProduct().getProductCategory(),offer.getOfferDescription(), offer.getOfferStartDate(),offer.getOfferEndDate(), offer.getDiscountOffered(),offer.getSoftDelete());
		
	}
	
	@RequestMapping(value="/getOfferByMerchantAndProduct/{merchantId}/{productId}")
	public double getMerchantAndProduct(@PathVariable int merchantId,@PathVariable int productId)
	{
		return service.findByMerchantAndProduct(merchantId,productId);
		
	}
	
}
